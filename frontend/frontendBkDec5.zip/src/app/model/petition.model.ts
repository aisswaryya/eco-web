export class Petition{
 _id:string;
 title: string;
 description: string;
 mediapath: string;
 email: string;
 username: string;
 }